﻿import { Component, ContentChild, ElementRef, OnInit } from '@angular/core';

@Component({
   selector: 'menu-bar',
   templateUrl: './menubar.html',
   styleUrls: ['./menubar.scss']
})

export class MenuBarComponent   implements OnInit {

    testdata: any;
    timer: any;
    
    sidewidth: number = 100; // with of the side
    collapsedwidth: number = 20; // with of the side at collapsed
    count: number = 1;
    maxcount: number=20;
    collapseshow: boolean = true;

    constructor(public element: ElementRef) {
        this.element.nativeElement // <- your direct element reference 
    }

    ngOnInit() {

     }

     collapseMenu(): void{
        this.count = 1; // initialized
        this.collapseshow = true;
        let stTimer =  setInterval(() => { 
            let w = this.sidewidth - Math.log10(this.count*5)*(this.sidewidth-this.collapsedwidth)*0.5;
            if(this.count < (this.maxcount+1))
            {
                this.count = this.count + 1;
                document.getElementById('menuid').style.width = w+'px';
                document.getElementById('rightnav').style.paddingLeft = (w-this.collapsedwidth)+'px';
                document.getElementById('leftnav').style.visibility = "hidden";
            }
            else
            {
                clearInterval(stTimer);
                this.collapseshow = false;
            }
            //console.log(w);
        }, 2);
     }

     showMenu(): void{
        this.count = 1;
        this.collapseshow = false;
        let stTimer =  setInterval(() => { 
            let w = this.collapsedwidth + Math.log10(this.count*5)*(this.sidewidth-this.collapsedwidth)*0.5;
            if(this.count < (this.maxcount+1))
            {
                this.count = this.count + 1;
                document.getElementById('menuid').style.width = w+'px';
                document.getElementById('rightnav').style.paddingLeft = (w-this.collapsedwidth)+'px';
            }
            else
            {
                clearInterval(stTimer);
                this.collapseshow = true;
                document.getElementById('leftnav').style.visibility = "visible";
            }
            //console.log(w);
        }, 2);
     }



}