import { Component } from '@angular/core';

@Component({
    selector: 'content',
    templateUrl: './content.html',
    styleUrls: ['./content.scss']
})

export class ContentComponent {
    
}